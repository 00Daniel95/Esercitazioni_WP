<?php
// Begin AIOWPSEC Firewall
if (file_exists('/Applications/MAMP/htdocs/wineblog/aios-bootstrap.php')) {
	include_once('/Applications/MAMP/htdocs/wineblog/aios-bootstrap.php');
}
// End AIOWPSEC Firewall
/**
 * Il file base di configurazione di WordPress.
 *
 * Questo file viene utilizzato, durante l’installazione, dallo script
 * di creazione di wp-config.php. Non è necessario utilizzarlo solo via web
 * puoi copiare questo file in «wp-config.php» e riempire i valori corretti.
 *
 * Questo file definisce le seguenti configurazioni:
 *
 * * Impostazioni del database
 * * Chiavi segrete
 * * Prefisso della tabella
 * * ABSPATH
 *
 * * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Impostazioni database - È possibile ottenere queste informazioni dal proprio fornitore di hosting ** //
/** Il nome del database di WordPress */
define( 'DB_NAME', 'esercitazioniwp' );

/** Nome utente del database */
define( 'DB_USER', 'root' );

/** Password del database */
define( 'DB_PASSWORD', 'root' );

/** Hostname del database */
define( 'DB_HOST', 'localhost' );

/** Charset del Database da utilizzare nella creazione delle tabelle. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Il tipo di collazione del database. Da non modificare se non si ha idea di cosa sia. */
define( 'DB_COLLATE', '' );

/**#@+
 * Chiavi univoche di autenticazione e di sicurezza.
 *
 * Modificarle con frasi univoche differenti!
 * È possibile generare tali chiavi utilizzando {@link https://api.wordpress.org/secret-key/1.1/salt/ servizio di chiavi-segrete di WordPress.org}
 *
 * È possibile cambiare queste chiavi in qualsiasi momento, per invalidare tutti i cookie esistenti.
 * Ciò forzerà tutti gli utenti a effettuare nuovamente l'accesso.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '#>|.*_Gl`A1_5/T(A<Z>:IY@Cs!y_PDgBs_guJ*cC1oKSy{@G{c C~$KJ8TSp+dT' );
define( 'SECURE_AUTH_KEY',  '9N~tz7!_$i_jl# Fo?Q7`w&%hGm0*8H l#r]Uj~ #;(FruY~s^91ABu6|[]m{{ZX' );
define( 'LOGGED_IN_KEY',    'qq@cht.FU>R610@vf$>C|F1b~k;Fm2%+3QecB;]Xh smwc:.o&.w1V_|LR>xthB*' );
define( 'NONCE_KEY',        '&%8llKNH$#b,vODG3RrF1Hr!bxfTU$*nj* RN`7&&(;l_d2BI#Ul,!q!?{|:xOl-' );
define( 'AUTH_SALT',        'x{AYpTj%;K<r>]*eTPdX^[xFt+yFPs_1K|75o0`vi}i2exV$I 6e9$~(R,h(I2qP' );
define( 'SECURE_AUTH_SALT', '=w}yHAP{>z^wEKTs.n(d/^}HO_9lDG6ltE~u ,|px$/k>=OX-RFqqxvxw]P3Uekv' );
define( 'LOGGED_IN_SALT',   ':aS.Pq/W(v]lcaR)du=Zv=z.2};5@*Vk?n}+0U;YO4f{CeR`gBFbX)d/YB61{:6b' );
define( 'NONCE_SALT',       '32t`C.=iAWf;]9^rXfU5.gWXMR2iZ~8Go3>` f,JWyg7Kl(Q<Y?Z7J4V=@1Wsn]u' );

/**#@-*/

/**
 * Prefisso tabella del database WordPress.
 *
 * È possibile avere installazioni multiple su di un unico database
 * fornendo a ciascuna installazione un prefisso univoco. Solo numeri, lettere e trattini bassi!
 */
$table_prefix = 'wp_';

/**
 * Per gli sviluppatori: modalità di debug di WordPress.
 *
 * Modificare questa voce a TRUE per abilitare la visualizzazione degli avvisi durante lo sviluppo
 * È fortemente raccomandato agli svilupaptori di temi e plugin di utilizare
 * WP_DEBUG all’interno dei loro ambienti di sviluppo.
 *
 * Per informazioni sulle altre costanti che possono essere utilizzate per il debug,
 * leggi la documentazione
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Aggiungere qualsiasi valore personalizzato tra questa riga e la riga "Finito, interrompere le modifiche". */



/* Finito, interrompere le modifiche! Buona pubblicazione. */

/** Path assoluto alla directory di WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Imposta le variabili di WordPress ed include i file. */
require_once ABSPATH . 'wp-settings.php';